import React from 'react';
import DepartmentForm from './features/Admin/DepartmentForm';
import Role from './features/Admin/RoleForm';
import AddEmployee from './features/Admin/AddEmployee';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import NavBar from './components/NavBar';
import Login from './features/auth/Login';
import Dashboard from './pages/Dashboard';

function App() {
  return (
    <BrowserRouter>
      <NavBar />
      <div className="container">
        <Routes>
          <Route path="/" element={Login} />
          <Route path="/daashboard" element={Dashboard} />
          <Route path="/departments" element={<DepartmentForm />} />
          <Route path="/roles" element={<Role />} />
          <Route path="/register" element={<AddEmployee />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
